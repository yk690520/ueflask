import ueflask.ue

setApp=ueflask.ue.setApp
