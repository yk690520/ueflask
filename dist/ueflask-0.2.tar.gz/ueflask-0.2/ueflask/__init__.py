from ueflask.uploader import Uploader
from ueflask.listFile import lists
from flask import request
from flask import json
from flask import Flask
import re,os
from flask import jsonify
#载入ue配置
ue_config=json.loads(re.sub("\/\*[\s\S]+?\*\/","",open(os.getcwd()+"/static/ue/config/config.json",encoding='utf8').read()))
def setApp(app):
    if isinstance(app,Flask):
        app.route("/controller", methods=['GET', 'POST'])(__controller)
    else:
        raise BaseException("不是标准的flask对象")
    pass
#ue的控制器处理方法
def __controller():
    action=request.args.get('action','')
    if action=="config":
        return jsonify(ue_config)
    elif request.method=='POST':
        config=None
        fieldName=None
        if action=="uploadimage":
            config={
                "pathFormat":ue_config['imagePathFormat'],
                "maxSize":ue_config['imageMaxSize'],
                "allowFiles":ue_config['imageAllowFiles']
            }
            fieldName=ue_config['imageFieldName']
        elif action=="uploadscrawl":#暂未实现
            return None
        elif action=="uploadvideo":
            config={
                "pathFormat":ue_config['videoPathFormat'],
                "maxSize":ue_config['videoMaxSize'],
                "allowFiles":ue_config['videoAllowFiles']
            }
            fieldName=ue_config['videoAllowFiles']
        else:
            config={
                "pathFormat": ue_config['filePathFormat'],
                "maxSize": ue_config['fileMaxSize'],
                "allowFiles": ue_config['fileAllowFiles']
            }
            fieldName=ue_config['fileFieldName']
        uploader=Uploader(fieldName,config)
        return jsonify(uploader.getFileInfo())
    #列出图片
    elif action=="listimage":
        config={'allowFiles':ue_config['imageManagerAllowFiles'],
                "listSize":ue_config['imageManagerListSize'],
                "path":ue_config['imageManagerListPath']
                }
        return jsonify(lists(config))

